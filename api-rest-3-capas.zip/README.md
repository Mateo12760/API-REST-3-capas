# API REST - Arquitectura en Tres Capas

Este proyecto implementa una API REST para gestionar productos, con una arquitectura en tres capas:

- **Capa de Presentación**: `routes/productoRoutes.js`
- **Capa de Lógica de Negocio**: `controllers/productoController.js`
- **Capa de Acceso a Datos**: `data/productoModel.js`

## Endpoints

- `GET /productos`: Lista los productos
- `POST /productos`: Agrega un nuevo producto

## Cómo ejecutar

1. Instalar dependencias: `npm install`
2. Ejecutar la app: `npm start`