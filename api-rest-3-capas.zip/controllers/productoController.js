const productoModel = require('../data/productoModel');

const listarProductos = (req, res) => {
  const productos = productoModel.obtenerProductos();
  res.json(productos);
};

const agregarProducto = (req, res) => {
  const nuevoProducto = req.body;
  productoModel.agregarProducto(nuevoProducto);
  res.status(201).json({ mensaje: 'Producto agregado con éxito' });
};

module.exports = { listarProductos, agregarProducto };