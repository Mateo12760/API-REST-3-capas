let productos = [];

const obtenerProductos = () => productos;

const agregarProducto = (producto) => {
  productos.push(producto);
};

module.exports = { obtenerProductos, agregarProducto };